<?php

namespace App\Http\Controllers\V1\User;

use App\Exceptions\ApiException;
use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Services\AgentPublicConfigService;
use App\Services\RechargeBonusService;
use App\Services\SiteContextService;
use App\Utils\Dict;
use Illuminate\Http\Request;

class CommController extends Controller
{
    public function config(Request $request)
    {
        $data = [
            'is_telegram' => (int)admin_setting('telegram_bot_enable', 0),
            'telegram_discuss_link' => admin_setting('telegram_discuss_link'),
            'stripe_pk' => admin_setting('stripe_pk_live'),
            'invite_gen_limit' => (int) admin_setting('invite_gen_limit', 5),
            'withdraw_methods' => admin_setting('commission_withdraw_method', Dict::WITHDRAW_METHOD_WHITELIST_DEFAULT),
            'withdraw_usdt_networks' => app(\App\Services\CommissionWithdrawalService::class)->networks(true),
            'withdraw_close' => (int)admin_setting('withdraw_close_enable', 0),
            'commission_withdraw_limit' => admin_setting('commission_withdraw_limit', 100),
            'currency' => admin_setting('currency', 'CNY'),
            'currency_symbol' => admin_setting('currency_symbol', '¥'),
            'commission_distribution_enable' => (int)admin_setting('commission_distribution_enable', 0),
            'commission_distribution_l1' => admin_setting('commission_distribution_l1'),
            'commission_distribution_l2' => admin_setting('commission_distribution_l2'),
            'commission_distribution_l3' => admin_setting('commission_distribution_l3'),
            'commission_first_time_enable' => (int)admin_setting('commission_first_time_enable', 1),
            'plan_change_enable' => (int)admin_setting('plan_change_enable', 1),
            'upgrade_v2_enable' => (int)admin_setting('upgrade_v2_enable', 0),
        ];
        $data = array_merge($data, app(RechargeBonusService::class)->getConfig());
        $data = app(SiteContextService::class)->applyToConfig($data, $request, $request->user());
        $data = app(AgentPublicConfigService::class)->apply($data, $request);
        $prepaid = app(\App\Services\AgentPrepaidService::class)->forRequest($request);
        if ($prepaid && $prepaid['active']) {
            $data['recharge_bonus_enable'] = 0;
            $data['recharge_bonus_rules'] = [];
            $data['agent_prepaid'] = $prepaid;
        }

        return $this->success($data)
            ->header('Cache-Control', 'no-store, private, max-age=0')
            ->header('Pragma', 'no-cache');
    }

    public function getStripePublicKey(Request $request)
    {
        $payment = Payment::where('id', $request->input('id'))
            ->where('payment', 'StripeCredit')
            ->first();
        if (!$payment) throw new ApiException('payment is not found');
        return $this->success($payment->config['stripe_pk_live']);
    }
}
