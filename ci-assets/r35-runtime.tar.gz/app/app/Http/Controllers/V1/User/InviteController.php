<?php

namespace App\Http\Controllers\V1\User;

use App\Exceptions\ApiException;
use App\Http\Controllers\Controller;
use App\Http\Resources\ComissionLogResource;
use App\Http\Resources\InviteCodeResource;
use App\Models\CommissionLog;
use App\Models\InviteCode;
use App\Models\Order;
use App\Models\User;
use App\Services\AgentCommerceContextResolver;
use App\Utils\Helper;
use Illuminate\Http\Request;

class InviteController extends Controller
{
    private const AGENT_SUBORDINATE_INVITE_DISABLED_MESSAGE = '代理下级用户不参与普通邀请返利';

    public function save(Request $request)
    {
        $user = $request->user();
        if (!$user) {
            throw new ApiException('未登录或登陆已过期', 403);
        }
        if ($this->isAgentSubordinate($user) || app(AgentCommerceContextResolver::class)->resolveRequest($request, $user) !== null) {
            return $this->fail([403, self::AGENT_SUBORDINATE_INVITE_DISABLED_MESSAGE]);
        }

        if (InviteCode::where('user_id', $user->id)->where('status', InviteCode::STATUS_UNUSED)->count() >= admin_setting('invite_gen_limit', 5)) {
            return $this->fail([400,__('The maximum number of creations has been reached')]);
        }
        $inviteCode = new InviteCode();
        $inviteCode->user_id = $user->id;
        $inviteCode->code = Helper::randomChar(8);

        try {
            return $this->success($inviteCode->save());
        } catch (\Throwable $e) {
            if ($e instanceof ApiException) {
                throw $e;
            }
            \Log::error('Failed to create invite code', ['exception' => $e, 'user_id' => $user->id]);
            throw new ApiException('创建邀请链接失败', 500);
        }
    }

    public function details(Request $request)
    {
        if ($this->isAgentSubordinate($request->user())) {
            return $this->fail([403, self::AGENT_SUBORDINATE_INVITE_DISABLED_MESSAGE]);
        }

        $current = $request->input('current') ? $request->input('current') : 1;
        $pageSize = $request->input('page_size') >= 10 ? $request->input('page_size') : 10;
        $builder = CommissionLog::where('invite_user_id', $request->user()->id)
            ->where('get_amount', '>', 0)
            ->orderBy('created_at', 'DESC');
        $total = $builder->count();
        $details = $builder->forPage($current, $pageSize)
            ->get();
        return response([
            'data' => ComissionLogResource::collection($details),
            'total' => $total
        ]);
    }

    public function fetch(Request $request)
    {
        $commission_rate = admin_setting('invite_commission', 10);
        $user = User::find($request->user()->id);
        if (!$user) {
            return $this->fail([400, __('The user does not exist')]);
        }
        if ($this->isAgentSubordinate($user)) {
            return $this->fail([403, self::AGENT_SUBORDINATE_INVITE_DISABLED_MESSAGE]);
        }

        $user->load(['codes' => fn($query) => $query->where('status', 0)]);
        if ($user->commission_rate) {
            $commission_rate = $user->commission_rate;
        }
        $uncheck_commission_balance = (int)Order::where('status', 3)
            ->where('commission_status', 0)
            ->where('invite_user_id', $user->id)
            ->sum('commission_balance');
        if (admin_setting('commission_distribution_enable', 0)) {
            $uncheck_commission_balance = $uncheck_commission_balance * (admin_setting('commission_distribution_l1') / 100);
        }
        $stat = [
            //已注册用户数
            (int)User::where('invite_user_id', $user->id)->count(),
            //有效的佣金
            (int)CommissionLog::where('invite_user_id', $user->id)
                ->sum('get_amount'),
            //确认中的佣金
            $uncheck_commission_balance,
            //佣金比例
            (int)$commission_rate,
            //可用佣金
            (int)$user->commission_balance
        ];
        $data = [
            'codes' => InviteCodeResource::collection($user->codes),
            'stat' => $stat
        ];
        return $this->success($data);
    }

    private function isAgentSubordinate(?User $user): bool
    {
        if (!$user) {
            return false;
        }

        return app(\App\Services\ReferralEligibilityService::class)->isAgentUser((int) $user->id);
    }
}
