<?php

namespace App\Http\Controllers\V2\Admin;

use App\Exceptions\ApiException;
use App\Http\Controllers\Controller;
use App\Models\AgentDomain;
use App\Models\Payment;
use App\Models\User;
use App\Services\PaymentService;
use App\Services\PaymentCollectionPolicyService;
use App\Services\PaytaroChannelService;
use App\Utils\Helper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    public function getPaymentMethods()
    {
        $methods = [];

        $pluginMethods = PaymentService::getAllPaymentMethodNames();
        $methods = array_merge($methods, $pluginMethods);

        return $this->success(array_unique($methods));
    }

    public function fetch()
    {
        $payments = Payment::query()->useWritePdo()->orderBy('sort', 'ASC')->get();
        $agentPayments = $payments->where('owner_type', Payment::OWNER_AGENT);
        $agentIds = $agentPayments->pluck('owner_id')->filter()->unique()->all();
        $domainIds = $agentPayments->pluck('owner_domain_id')->filter()->unique()->all();
        $agentEmails = $agentIds ? User::query()->useWritePdo()->whereIn('id', $agentIds)->pluck('email', 'id') : collect();
        $domains = $domainIds ? AgentDomain::query()->useWritePdo()->whereIn('id', $domainIds)->get(['id', 'agent_user_id', 'domain'])->keyBy('id') : collect();
        $policy = app(PaymentCollectionPolicyService::class);
        $now = $policy->now();
        $totals = $policy->dailyTotals($payments, $now);
        foreach ($payments as $k => $v) {
            $domain = $domains->get($v->owner_domain_id);
            $payments[$k]['agent_email'] = $v->owner_type === Payment::OWNER_AGENT ? $agentEmails->get($v->owner_id) : null;
            $payments[$k]['owner_domain'] = $v->owner_type === Payment::OWNER_AGENT && $domain && (int) $domain->agent_user_id === $v->owner_id
                ? $domain->domain : null;
            $payments[$k]['collection_state'] = $policy->state($v, $totals[$v->id] ?? 0, $now);
            $notifyUrl = url("/api/v1/guest/payment/notify/{$v->payment}/{$v->uuid}");
            if ($v->notify_domain) {
                $parseUrl = parse_url($notifyUrl);
                $notifyUrl = $v->notify_domain . $parseUrl['path'];
            }
            $payments[$k]['notify_url'] = $notifyUrl;
        }
        return $this->success($payments)->header('Cache-Control', 'private, no-store, max-age=0');
    }

    public function getPaymentForm(Request $request)
    {
        try {
            $paymentService = new PaymentService($request->input('payment'), $request->input('id'));
            return $this->success(collect($paymentService->form()));
        } catch (\Exception $e) {
            return $this->fail([400, '支付方式不存在或未启用']);
        }
    }

    public function getPaytaroChannels(Request $request)
    {
        $params = $request->validate([
            'app_id' => ['required', 'string', 'max:128'],
            'app_secret' => ['required', 'string', 'max:512'],
        ]);
        try {
            return $this->success(app(PaytaroChannelService::class)->fetch($params['app_id'], $params['app_secret']));
        } catch (ApiException $e) {
            return $this->fail([400, $e->getMessage()]);
        }
    }

    public function show(Request $request)
    {
        $payment = Payment::find($request->input('id'));
        if (!$payment)
            return $this->fail([400202, '支付方式不存在']);
        $payment->enable = !$payment->enable;
        if (!$payment->save())
            return $this->fail([500, '保存失败']);
        return $this->success(true);
    }

    public function save(Request $request)
    {
        if (!admin_setting('app_url')) {
            return $this->fail([400, '请在站点配置中配置站点地址']);
        }
        $params = $request->validate([
            'name' => 'required',
            'icon' => 'nullable',
            'payment' => 'required',
            'config' => 'required',
            'notify_domain' => 'nullable|url',
            'handling_fee_fixed' => 'nullable|integer',
            'handling_fee_percent' => 'nullable|numeric|between:0,100',
            'collection_policy' => 'sometimes|nullable|array',
        ], [
            'name.required' => '显示名称不能为空',
            'payment.required' => '网关参数不能为空',
            'config.required' => '配置参数不能为空',
            'notify_domain.url' => '自定义通知域名格式有误',
            'handling_fee_fixed.integer' => '固定手续费格式有误',
            'handling_fee_percent.between' => '百分比手续费范围须在0-100之间'
        ]);
        if (array_key_exists('collection_policy', $params)) {
            $params['collection_policy'] = app(PaymentCollectionPolicyService::class)->validate($params['collection_policy']);
        }
        if ($request->input('id')) {
            $payment = Payment::find($request->input('id'));
            if (!$payment)
                return $this->fail([400202, '支付方式不存在']);
            try {
                $payment->update($params);
            } catch (\Exception $e) {
                Log::error($e);
                return $this->fail([500, '保存失败']);
            }
            return $this->success(true);
        }
        $params['uuid'] = Helper::randomChar(8);
        $params['owner_type'] = Payment::OWNER_PLATFORM;
        $params['owner_id'] = null;
        $params['owner_domain_id'] = null;
        if (!Payment::create($params)) {
            return $this->fail([500, '保存失败']);
        }
        return $this->success(true);
    }

    public function drop(Request $request)
    {
        $params = $request->validate(['id' => 'required|integer|min:1']);
        $payment = Payment::query()->useWritePdo()->find($params['id']);
        if (!$payment)
            return $this->fail([400202, '支付方式不存在']);
        if (!$payment->delete())
            return $this->fail([500, '删除失败，支付方式未移除']);
        return $this->success(true);
    }


    public function sort(Request $request)
    {
        $params = $request->validate([
            'ids' => 'required|array|min:1',
            'ids.*' => 'required|integer|min:1|distinct',
        ], [
            'ids.required' => '参数有误',
            'ids.array' => '参数有误'
        ]);
        try {
            DB::beginTransaction();
            $payments = Payment::query()->whereIn('id', $params['ids'])->lockForUpdate()->get()->keyBy('id');
            $owners = $payments->map(function (Payment $payment): ?string {
                if ($payment->owner_type === Payment::OWNER_PLATFORM && $payment->owner_id === null && $payment->owner_domain_id === null) {
                    return Payment::OWNER_PLATFORM;
                }
                return $payment->owner_type === Payment::OWNER_AGENT && $payment->owner_id > 0
                    ? Payment::OWNER_AGENT . ':' . $payment->owner_id : null;
            });
            if ($payments->count() !== count($params['ids']) || $owners->contains(null) || $owners->unique()->count() !== 1) {
                DB::rollBack();
                return $this->fail([400, '仅可对同一收款主体的支付方式排序']);
            }
            foreach (array_values($params['ids']) as $k => $v) {
                if (!$payments->get($v)->update(['sort' => $k + 1])) {
                    throw new \Exception();
                }
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->fail([500, '保存失败']);
        }

        return $this->success(true);
    }
}
