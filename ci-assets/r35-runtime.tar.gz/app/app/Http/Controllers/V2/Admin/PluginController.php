<?php

namespace App\Http\Controllers\V2\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plugin;
use App\Services\Plugin\PluginManager;
use App\Services\Plugin\PluginConfigService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class PluginController extends Controller
{
    protected PluginManager $pluginManager;
    protected PluginConfigService $configService;

    public function __construct(
        PluginManager $pluginManager,
        PluginConfigService $configService
    ) {
        $this->pluginManager = $pluginManager;
        $this->configService = $configService;
    }

    /**
     * Plugin endpoints used to return raw {data}/{message}. They now use the
     * standard API envelope while keeping those top-level fields for clients
     * during the migration window.
     */
    private function pluginSuccess(mixed $data = null, ?string $message = null): JsonResponse
    {
        return $message === null
            ? $this->success($data)
            : $this->success($data, [200001, $message]);
    }

    private function pluginFail(string $message, int $httpStatus = 400): JsonResponse
    {
        return $this->fail([$httpStatus, $message]);
    }

    /**
     * 获取所有插件类型
     */
    public function types()
    {
        return $this->pluginSuccess([
            [
                'value' => Plugin::TYPE_FEATURE,
                'label' => '功能',
                'description' => '提供功能扩展的插件，如Telegram登录、邮件通知等',
                'icon' => '🔧'
            ],
            [
                'value' => Plugin::TYPE_PAYMENT,
                'label' => '支付方式',
                'description' => '提供支付接口的插件，如支付宝、微信支付等',
                'icon' => '💳'
            ]
        ]);
    }

    /**
     * 获取插件列表
     */
    public function index(Request $request)
    {
        $type = $request->query('type');

        $installedPlugins = Plugin::when($type, function ($query) use ($type) {
            return $query->byType($type);
        })
            ->get()
            ->keyBy('code')
            ->toArray();

        $plugins = [];

        $directories = $this->pluginManager->getPluginDirectories();
        if ($directories !== []) {
            foreach ($directories as $directory) {
                $pluginName = basename($directory);
                $configFile = $directory . '/config.json';
                if (File::exists($configFile)) {
                    $config = json_decode(File::get($configFile), true);
                    if (!is_array($config) || !is_string($config['code'] ?? null)
                        || realpath($directory) !== realpath($this->pluginManager->getPluginPath($config['code']))) {
                        continue;
                    }
                    $code = $config['code'];
                    $isCore = $this->pluginManager->isCorePlugin($code);
                    $pluginType = $config['type'] ?? Plugin::TYPE_FEATURE;

                    // 如果指定了类型，过滤插件
                    if ($type && $pluginType !== $type) {
                        continue;
                    }

                    $installed = isset($installedPlugins[$code]);
                    $pluginConfig = $installed ? $this->configService->getConfig($code) : ($config['config'] ?? []);
                    $readmeFile = collect(['README.md', 'readme.md'])
                        ->map(fn($f) => $directory . '/' . $f)
                        ->first(fn($path) => File::exists($path));
                    $readmeContent = $readmeFile ? File::get($readmeFile) : '';
                    $needUpgrade = false;
                    if ($installed) {
                        $installedVersion = $installedPlugins[$code]['version'] ?? null;
                        $localVersion = $config['version'] ?? null;
                        if ($installedVersion && $localVersion && version_compare($localVersion, $installedVersion, '>')) {
                            $needUpgrade = true;
                        }
                    }
                    $plugins[] = [
                        'code' => $config['code'],
                        'name' => $config['name'],
                        'version' => $config['version'],
                        'description' => $config['description'],
                        'author' => $config['author'],
                        'type' => $pluginType,
                        'is_installed' => $installed,
                        'is_enabled' => $installed ? $installedPlugins[$code]['is_enabled'] : false,
                        'is_core' => $isCore,
                        'is_protected' => $isCore || in_array($code, Plugin::PROTECTED_PLUGINS, true),
                        'can_be_deleted' => !$isCore && !in_array($code, Plugin::PROTECTED_PLUGINS, true),
                        'config' => $pluginConfig,
                        'readme' => $readmeContent,
                        'need_upgrade' => $needUpgrade,
                    ];
                }
            }
        }

        return $this->pluginSuccess($plugins);
    }

    /**
     * 安装插件
     */
    public function install(Request $request)
    {
        $request->validate([
            'code' => 'required|string'
        ]);

        try {
            $this->pluginManager->install($request->input('code'));
            return $this->pluginSuccess(null, '插件安装成功');
        } catch (\Exception $e) {
            return $this->pluginFail('插件安装失败：' . $e->getMessage());
        }
    }

    /**
     * 卸载插件
     */
    public function uninstall(Request $request)
    {
        $request->validate([
            'code' => 'required|string'
        ]);

        $code = $request->input('code');
        $plugin = Plugin::where('code', $code)->first();
        if ($plugin && $plugin->is_enabled) {
            return $this->pluginFail('请先禁用插件后再卸载');
        }

        try {
            $this->pluginManager->uninstall($code);
            return $this->pluginSuccess(null, '插件卸载成功');
        } catch (\Exception $e) {
            return $this->pluginFail('插件卸载失败：' . $e->getMessage());
        }
    }

    /**
     * 升级插件
     */
    public function upgrade(Request $request)
    {
        $request->validate([
            'code' => 'required|string',
        ]);
        try {
            $this->pluginManager->update($request->input('code'));
            return $this->pluginSuccess(null, '插件升级成功');
        } catch (\Exception $e) {
            return $this->pluginFail('插件升级失败：' . $e->getMessage());
        }
    }

    /**
     * 启用插件
     */
    public function enable(Request $request)
    {
        $request->validate([
            'code' => 'required|string'
        ]);

        try {
            $this->pluginManager->enable($request->input('code'));
            return $this->pluginSuccess(null, '插件启用成功');
        } catch (\Exception $e) {
            return $this->pluginFail('插件启用失败：' . $e->getMessage());
        }
    }

    /**
     * 禁用插件
     */
    public function disable(Request $request)
    {
        $request->validate([
            'code' => 'required|string'
        ]);

        $this->pluginManager->disable($request->input('code'));
        return $this->pluginSuccess(null, '插件禁用成功');

    }

    /**
     * 获取插件配置
     */
    public function getConfig(Request $request)
    {
        $request->validate([
            'code' => 'required|string'
        ]);

        try {
            $config = $this->configService->getConfig($request->input('code'));
            return $this->pluginSuccess($config);
        } catch (\Exception $e) {
            return $this->pluginFail('获取配置失败：' . $e->getMessage());
        }
    }

    /**
     * 更新插件配置
     */
    public function updateConfig(Request $request)
    {
        $request->validate([
            'code' => 'required|string',
            'config' => 'required|array'
        ]);

        try {
            $this->configService->updateConfig(
                $request->input('code'),
                $request->input('config')
            );

            return $this->pluginSuccess(null, '配置更新成功');
        } catch (\Exception $e) {
            return $this->pluginFail('配置更新失败：' . $e->getMessage());
        }
    }

    /**
     * 上传插件
     */
    public function upload(Request $request)
    {
        $request->validate([
            'file' => [
                'required',
                'file',
                'mimes:zip',
                'max:10240', // 最大10MB
            ]
        ], [
            'file.required' => '请选择插件包文件',
            'file.file' => '无效的文件类型',
            'file.mimes' => '插件包必须是zip格式',
            'file.max' => '插件包大小不能超过10MB'
        ]);

        try {
            $this->pluginManager->upload($request->file('file'));
            return $this->pluginSuccess(null, '插件上传成功');
        } catch (\Exception $e) {
            return $this->pluginFail('插件上传失败：' . $e->getMessage());
        }
    }

    /**
     * 删除插件
     */
    public function delete(Request $request)
    {
        $request->validate([
            'code' => 'required|string'
        ]);

        $code = $request->input('code');

        // 检查是否为受保护的插件
        if ($this->pluginManager->isCorePlugin($code) || in_array($code, Plugin::PROTECTED_PLUGINS, true)) {
            return $this->pluginFail('该插件为系统默认插件，不允许删除', 403);
        }

        try {
            $this->pluginManager->delete($code);
            return $this->pluginSuccess(null, '插件删除成功');
        } catch (\Exception $e) {
            return $this->pluginFail('插件删除失败：' . $e->getMessage());
        }
    }
}
