<?php

namespace App\Http\Controllers\V2\Server;

use App\Http\Controllers\Controller;
use App\Jobs\UpdateAliveDataJob;
use App\Services\NodeRealtime\NodeRealtimeSettings;
use App\Services\UserService;
use App\Utils\CacheKey;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class ServerController extends Controller
{
    private function getNodeInfo(Request $request)
    {
        return $request->attributes->get('node_info');
    }

    private function getNodeCacheServerId($node): int
    {
        return (int) ($node->parent_id ?: $node->id);
    }

    private function touchNodeLastCheckAt($node): void
    {
        $nodeType = (string) $node->type;
        $nodeId = $this->getNodeCacheServerId($node);
        Cache::put(CacheKey::get('SERVER_' . strtoupper($nodeType) . '_LAST_CHECK_AT', $nodeId), time(), 3600);
    }

    public function handshake(Request $request): JsonResponse
    {
        $node = $this->getNodeInfo($request);
        if ($node) {
            $this->touchNodeLastCheckAt($node);
        }

        $settings = app(NodeRealtimeSettings::class);
        $wsURL = $settings->resolvedPublicUrl();
        $enabled = $settings->enabled() && $wsURL !== '';

        return response()->json([
            'websocket' => [
                'enabled' => $enabled,
                'ws_url' => $enabled ? $wsURL : '',
            ],
            'settings' => [
                'push_interval' => (int) admin_setting('server_push_interval', 60),
                'pull_interval' => (int) admin_setting('server_pull_interval', 60),
            ],
        ]);
    }

    public function report(Request $request): JsonResponse
    {
        $node = $this->getNodeInfo($request);
        $this->touchNodeLastCheckAt($node);

        $nodeType = (string) $node->type;
        $nodeId = $this->getNodeCacheServerId($node);
        $pushInterval = max(1, (int) admin_setting('server_push_interval', 60));
        $source = \App\Services\Node\NodeReportSource::from($request);
        $cacheTime = max(300, $pushInterval * 3);
        $onlineCacheTime = max(120, $pushInterval * 3);

        $trafficRaw = $request->input('traffic');
        $traffic = [];
        if (is_array($trafficRaw)) {
            $traffic = array_filter($trafficRaw, function ($item) {
                return is_array($item)
                    && count($item) === 2
                    && is_numeric($item[0] ?? null)
                    && is_numeric($item[1] ?? null);
            });
        }
        if (!empty($traffic)) {
            $userService = new UserService();
            $userService->trafficFetch($node, $nodeType, $traffic);
            app(\App\Services\Node\NodeInstanceRegistry::class)->record($node, $request, ['last_traffic_at' => time()]);
            Cache::put(CacheKey::get('SERVER_' . strtoupper($nodeType) . '_LAST_PUSH_AT', $nodeId), time(), 3600);
        }

        $alive = $request->input('alive');
        if (is_array($alive)) {
            app(\App\Services\Node\NodeInstanceRegistry::class)->record($node, $request, ['online_users' => count($alive), 'last_online_at' => time()]);
            UpdateAliveDataJob::dispatch($alive, $nodeType, $node->id, null, $source['key'], $source['machine_id'], $nodeId);
            Cache::put(CacheKey::get('SERVER_' . strtoupper($nodeType) . '_LAST_PUSH_AT', $nodeId), time(), 3600);
        }

        $online = $request->input('online');
        if (is_array($online) && !$source['identified'] && count(app(\App\Services\Node\NodeInstanceRegistry::class)->snapshot((int) $node->id)) <= 1) {
            $onlineUserCount = 0;
            foreach ($online as $count) {
                if ((int) $count > 0) {
                    $onlineUserCount++;
                }
            }
            Cache::put(
                CacheKey::get('SERVER_' . strtoupper($nodeType) . '_ONLINE_USER', $nodeId),
                $onlineUserCount,
                $onlineCacheTime
            );
            Cache::put(CacheKey::get('SERVER_' . strtoupper($nodeType) . '_LAST_PUSH_AT', $nodeId), time(), 3600);
        }

        $status = $request->input('status');
        if (is_array($status)
            && is_numeric($status['cpu'] ?? null)
            && is_numeric(data_get($status, 'mem.total'))
            && is_numeric(data_get($status, 'mem.used'))
            && is_numeric(data_get($status, 'swap.total', 0))
            && is_numeric(data_get($status, 'swap.used', 0))
            && is_numeric(data_get($status, 'disk.total', 0))
            && is_numeric(data_get($status, 'disk.used', 0))
        ) {
            app(\App\Services\Node\NodeInstanceRegistry::class)->recordStatus($node, $request, $status);
            $statusData = [
                'cpu' => (float) $status['cpu'],
                'mem' => [
                    'total' => (int) data_get($status, 'mem.total', 0),
                    'used' => (int) data_get($status, 'mem.used', 0),
                ],
                'swap' => [
                    'total' => (int) data_get($status, 'swap.total', 0),
                    'used' => (int) data_get($status, 'swap.used', 0),
                ],
                'disk' => [
                    'total' => (int) data_get($status, 'disk.total', 0),
                    'used' => (int) data_get($status, 'disk.used', 0),
                ],
                'updated_at' => now()->timestamp,
            ];
            if (count(app(\App\Services\Node\NodeInstanceRegistry::class)->snapshot((int) $node->id)) <= 1) cache([
                CacheKey::get('SERVER_' . strtoupper($nodeType) . '_LOAD_STATUS', $nodeId) => $statusData,
                CacheKey::get('SERVER_' . strtoupper($nodeType) . '_LAST_LOAD_AT', $nodeId) => now()->timestamp,
            ], $cacheTime);
            else Cache::forget(CacheKey::get('SERVER_' . strtoupper($nodeType) . '_LOAD_STATUS', $nodeId));
        }

        $metrics = $request->input('metrics');
        if (is_array($metrics) && !empty($metrics)) {
            if (count(app(\App\Services\Node\NodeInstanceRegistry::class)->snapshot((int) $node->id)) <= 1) {
                Cache::put(CacheKey::get('SERVER_' . strtoupper($nodeType) . '_METRICS', $nodeId), $metrics, $cacheTime);
            } else Cache::forget(CacheKey::get('SERVER_' . strtoupper($nodeType) . '_METRICS', $nodeId));
        }

        return response()->json(['data' => true]);
    }
}
