<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Payment extends Model
{
    use SoftDeletes;

    protected $table = 'v2_payment';
    protected $dateFormat = 'U';
    protected $guarded = ['id'];

    public const OWNER_PLATFORM = 'platform';
    public const OWNER_AGENT = 'agent';

    protected $casts = [
        'created_at' => 'timestamp',
        'updated_at' => 'timestamp',
        'config' => 'array',
        'collection_policy' => 'array',
        'enable' => 'boolean',
        'owner_id' => 'integer',
        'owner_domain_id' => 'integer',
    ];
}
