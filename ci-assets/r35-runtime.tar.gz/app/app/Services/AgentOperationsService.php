<?php

declare(strict_types=1);

namespace App\Services;

use App\Exceptions\ApiException;
use App\Models\AgentBalanceHold;
use App\Models\AgentDomain;
use App\Models\AgentOrderContext;
use App\Models\AgentProfile;
use App\Models\AgentUser;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Site;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;

class AgentOperationsService
{
    public function __construct(private AgentOrderStatusResolver $statusResolver) {}

    /**
     * @return array<string, int>
     */
    public function agentSummary(User $agent): array
    {
        return $this->summaryForAgent($agent);
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{data: array<int, array<string, mixed>>, total: int, page: int, page_size: int}
     */
    public function agentOrders(User $agent, array $filters): array
    {
        return $this->paginatedOrders($this->orderQuery($agent->id), $filters);
    }

    /**
     * @return array<string, mixed>
     */
    public function agentOrderDetail(User $agent, string $tradeNo): array
    {
        $context = $this->orderQuery($agent->id)
            ->where('trade_no', $tradeNo)
            ->first();

        if ($context === null) {
            throw new ApiException('Agent order not found');
        }

        return $this->orderRow($context);
    }

    /**
     * @return array<string, int>
     */
    public function adminSummary(): array
    {
        $totals = [
            'active_agent_count' => 0,
            'pending_hold_total' => 0,
            'abnormal_order_count' => 0,
            'insufficient_balance_agent_count' => 0,
            'no_active_payment_agent_count' => 0,
        ];
        $agents = $this->adminAgentQuery()->lazyById(100);
        foreach ($agents as $agent) {
            $hold = app(AgentCommerceService::class)->activePendingHoldTotal((int) $agent->id);
            $totals['active_agent_count'] += $agent->profile_status === AgentCenterService::STATUS_ACTIVE && !$agent->banned ? 1 : 0;
            $totals['pending_hold_total'] += $hold;
            $totals['abnormal_order_count'] += $this->abnormalOrderCount((int) $agent->id);
            $totals['insufficient_balance_agent_count'] += $hold > 0 && (int) $agent->balance <= $hold ? 1 : 0;
            $totals['no_active_payment_agent_count'] += $this->enabledPaymentCount((int) $agent->id) === 0 ? 1 : 0;
        }
        return $totals;
    }

    /**
     * @return array<string, int>
     */
    public function adminReconciliation(): array
    {
        $totals = [
            'context_count' => 0,
            'paid_sales_total' => 0,
            'captured_cost_total' => 0,
            'pending_hold_total' => 0,
            'released_hold_total' => 0,
            'refunded_total' => 0,
            'refunded_order_count' => 0,
            'abnormal_order_count' => 0,
        ];

        $contexts = AgentOrderContext::query()
            ->with(['order', 'hold', 'payment'])
            ->orderBy('id')
            ->lazyById(250);

        foreach ($contexts as $context) {
            $totals['context_count']++;
            $resolved = $this->statusResolver->resolve($context);
            $order = $context->order;
            $hold = $context->hold;

            $platformRecharge = app(AgentCollectionService::class)->isPlatform($context)
                && ($context->pricing_snapshot['type'] ?? '') === 'recharge';
            if ($context->status === AgentOrderContext::STATUS_PAID && !$platformRecharge) {
                $totals['paid_sales_total'] += (int) $context->sale_amount;
            }
            if ($resolved['capture_status'] === AgentBalanceHold::STATUS_CAPTURED) {
                $totals['captured_cost_total'] += (int) $context->cost_amount;
            }
            if (
                $hold !== null
                && $hold->status === AgentBalanceHold::STATUS_PENDING
                && $order !== null
                && in_array((int) $order->status, [Order::STATUS_PENDING, Order::STATUS_PROCESSING], true)
            ) {
                $totals['pending_hold_total'] += (int) $hold->amount;
            }
            if ($resolved['capture_status'] === AgentBalanceHold::STATUS_RELEASED) {
                $totals['released_hold_total'] += (int) ($hold?->amount ?? $context->cost_amount);
            }

            $refundAmount = max(0, (int) ($order?->refund_amount ?? 0));
            if ($refundAmount > 0) {
                $totals['refunded_total'] += $refundAmount;
                $totals['refunded_order_count']++;
            }
            if (count($resolved['abnormal_flags']) > 0) {
                $totals['abnormal_order_count']++;
            }
        }

        return $totals;
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{data: array<int, array<string, mixed>>, total: int, page: int, page_size: int}
     */
    public function adminAgents(array $filters): array
    {
        $page = $this->positiveInt($filters['page'] ?? 1, 1);
        $pageSize = min(100, $this->positiveInt($filters['page_size'] ?? 20, 20));
        $keyword = trim((string) ($filters['keyword'] ?? ''));

        $query = $this->adminAgentQuery()->orderBy('id');

        if ($keyword !== '') {
            $query->where(function (Builder $search) use ($keyword): void {
                $search->where('email', 'like', '%' . $keyword . '%');
                if (ctype_digit($keyword)) {
                    $search->orWhere('id', (int) $keyword);
                }
            });
        }
        if (filter_var($filters['abnormal'] ?? false, FILTER_VALIDATE_BOOL)) {
            $query->whereIn('id', $this->statusResolver->filterAbnormal(AgentOrderContext::query())->select('agent_user_id'));
        }

        $total = (int) $query->count();
        $agents = $query->forPage($page, $pageSize)->get();
        $data = [];

        foreach ($agents as $agent) {
            $data[] = $this->adminAgentRow($agent);
        }

        return [
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function adminAgentDetail(int $agentUserId): array
    {
        $agent = $this->adminAgentQuery()->find($agentUserId);
        if ($agent === null) {
            throw new ApiException('Agent not found');
        }

        return array_merge($this->adminAgentRow($agent), [
            'domains' => AgentDomain::query()->where('agent_user_id', $agentUserId)->orderBy('id')
                ->get(['id', 'domain', 'status', 'is_primary'])->map(static fn ($row): array => [
                    'id' => (int) $row->id, 'domain' => $row->domain,
                    'status' => $row->status, 'is_primary' => (bool) $row->is_primary,
                ])->all(),
            'payments' => Payment::query()->where('owner_type', Payment::OWNER_AGENT)->where('owner_id', $agentUserId)->orderBy('id')
                ->get(['id', 'name', 'payment', 'enable', 'owner_domain_id'])->map(static fn ($row): array => [
                    'id' => (int) $row->id, 'name' => $row->name, 'payment' => $row->payment,
                    'enable' => (bool) $row->enable, 'owner_domain_id' => $row->owner_domain_id,
                ])->all(),
        ]);
    }

    public function adminAgentQuery(): Builder
    {
        return User::query()->select('v2_user.*')->where(function (Builder $query): void {
            $query->whereIn('id', AgentProfile::query()->select('user_id'))
                ->orWhereIn('id', AgentOrderContext::query()->select('agent_user_id'))
                ->orWhereIn('id', AgentUser::query()->select('agent_user_id'));
        })->addSelect([
            'profile_status' => AgentProfile::query()->select('status')->whereColumn('user_id', 'v2_user.id')->limit(1),
            'subordinate_count' => AgentUser::query()->selectRaw('COUNT(*)')->whereColumn('agent_user_id', 'v2_user.id')->whereHas('subordinate'),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public function updateAgentCostSite(int $agentUserId, ?int $siteId): array
    {
        $agent = User::query()->find($agentUserId);
        if ($agent === null) {
            throw new ApiException('Agent not found');
        }

        $profile = AgentProfile::query()
            ->where('user_id', $agentUserId)
            ->first();
        if ($profile === null) {
            throw new ApiException('Agent profile not found');
        }

        $profile->cost_site_id = $this->validCostSiteId($siteId);
        $profile->updated_at = time();
        $profile->save();

        return $this->adminAgentDetail($agentUserId);
    }

    /**
     * @return array<string, mixed>
     */
    private function adminAgentRow(User $agent): array
    {
        return array_merge([
            'agent_user_id' => (int) $agent->id,
            'agent_email' => $agent->email,
            'status' => $agent->banned ? 'banned' : ($agent->profile_status ?? 'legacy'),
            'subordinate_count' => (int) $agent->subordinate_count,
        ], $this->summaryForAgent($agent), [
            'active_domain_count' => $this->activeDomainCount((int) $agent->id),
            'enabled_payment_count' => $this->enabledPaymentCount((int) $agent->id),
            'cost_site' => $this->costSitePayloadForAgent((int) $agent->id),
        ]);
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{data: array<int, array<string, mixed>>, total: int, page: int, page_size: int}
     */
    public function adminOrdersForAgent(int $agentUserId, array $filters): array
    {
        return $this->paginatedOrders($this->orderQuery($agentUserId), $filters);
    }

    /**
     * @return array<string, int>
     */
    private function summaryForAgent(User $agent): array
    {
        $agentUserId = (int) $agent->id;
        $pendingHoldTotal = app(AgentCommerceService::class)->activePendingHoldTotal($agentUserId);

        $month = $this->contextsForMonth($agentUserId)->reorder()->toBase()
            ->selectRaw('COALESCE(SUM(sale_amount), 0) AS sales, COALESCE(SUM(cost_amount), 0) AS cost')->first();
        $monthSalesTotal = (int) $month->sales;
        $monthCostTotal = (int) $month->cost;
        $monthCollectionFees = (int) $this->contextsForMonth($agentUserId)->reorder()->toBase()
            ->sum('pricing_snapshot->collection_fee_amount');
        $recharges = $this->contextsForMonth($agentUserId)->where('pricing_snapshot->collection->mode', 'platform')
            ->where('pricing_snapshot->type', 'recharge');
        $rechargePrincipal = (int) (clone $recharges)->sum('sale_amount');
        $rechargeFees = (int) (clone $recharges)->reorder()->toBase()->sum('pricing_snapshot->collection_fee_amount');
        $monthSalesTotal -= $rechargePrincipal;
        $monthMarginTotal = $monthSalesTotal - $monthCostTotal - $monthCollectionFees + $rechargeFees;

        return [
            'balance' => (int) ($agent->balance ?? 0),
            'available_balance' => max(0, (int) ($agent->balance ?? 0) - $pendingHoldTotal),
            'pending_hold_total' => $pendingHoldTotal,
            'month_sales_total' => $monthSalesTotal,
            'month_cost_total' => $monthCostTotal,
            'month_margin_total' => $monthMarginTotal,
            'pending_order_count' => (int) AgentOrderContext::query()
                ->where('agent_user_id', $agentUserId)
                ->where('status', AgentOrderContext::STATUS_PENDING)
                ->whereHas('order', function (Builder $query): void {
                    $query->whereIn('status', [
                        Order::STATUS_PENDING,
                        Order::STATUS_PROCESSING,
                    ]);
                })
                ->count(),
            'abnormal_order_count' => $this->abnormalOrderCount($agentUserId),
        ];
    }

    private function contextsForMonth(int $agentUserId): Builder
    {
        $start = strtotime(date('Y-m-01 00:00:00')) ?: time();
        $end = strtotime(date('Y-m-t 23:59:59')) ?: time();

        return $this->orderQuery($agentUserId)
            ->where('status', AgentOrderContext::STATUS_PAID)
            ->whereBetween('created_at', [$start, $end]);
    }

    private function abnormalOrderCount(int $agentUserId): int
    {
        return $this->statusResolver->filterAbnormal($this->orderQuery($agentUserId))->count();
    }

    private function orderQuery(int $agentUserId): Builder
    {
        return AgentOrderContext::query()
            ->with(['agent', 'order.user', 'order.plan', 'domain', 'hold', 'payment'])
            ->where('agent_user_id', $agentUserId)
            ->orderByDesc('created_at')
            ->orderByDesc('id');
    }

    /**
     * @param Builder<AgentOrderContext> $query
     * @param array<string, mixed> $filters
     * @return array{data: array<int, array<string, mixed>>, total: int, page: int, page_size: int}
     */
    private function paginatedOrders(Builder $query, array $filters): array
    {
        $page = $this->positiveInt($filters['page'] ?? 1, 1);
        $pageSize = min(100, $this->positiveInt($filters['page_size'] ?? 20, 20));
        $this->applyOrderFilters($query, $filters);

        if (array_key_exists('abnormal', $filters)) {
            $expectAbnormal = filter_var($filters['abnormal'], FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($expectAbnormal !== null) {
                $this->statusResolver->filterAbnormal($query, $expectAbnormal);
            }
        }

        $total = (clone $query)->count();
        $rows = $query->forPage($page, $pageSize)->get()
            ->map(fn (AgentOrderContext $context): array => $this->orderRow($context));

        return [
            'data' => $rows->values()->all(),
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize,
        ];
    }

    /**
     * @param Builder<AgentOrderContext> $query
     * @param array<string, mixed> $filters
     */
    private function applyOrderFilters(Builder $query, array $filters): void
    {
        if (isset($filters['status']) && $filters['status'] !== '') {
            $query->where('status', (string) $filters['status']);
        }

        if (isset($filters['domain_id']) && $filters['domain_id'] !== '') {
            $query->where('agent_domain_id', (int) $filters['domain_id']);
        }

        if (isset($filters['payment_id']) && $filters['payment_id'] !== '') {
            $query->where('payment_id', (int) $filters['payment_id']);
        }

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->where(function (Builder $keywordQuery) use ($keyword): void {
                $like = '%' . $keyword . '%';
                $keywordQuery->where('trade_no', 'like', $like)
                    ->orWhereHas('order.user', static function (Builder $userQuery) use ($like): void {
                        $userQuery->where('email', 'like', $like);
                    })
                    ->orWhereHas('domain', static function (Builder $domainQuery) use ($like): void {
                        $domainQuery->where('domain', 'like', $like);
                    });
            });
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function orderRow(AgentOrderContext $context): array
    {
        $resolved = $this->statusResolver->resolve($context);
        $order = $context->order;
        $buyer = $order?->user;
        $agent = $context->agent;
        $domain = $context->domain;
        $payment = $context->payment;

        return [
            'id' => (int) $context->id,
            'order_id' => $context->order_id === null ? null : (int) $context->order_id,
            'trade_no' => $context->trade_no,
            'buyer_user_id' => $buyer?->id === null ? null : (int) $buyer->id,
            'buyer_email' => $buyer?->email,
            'agent_user_id' => (int) $context->agent_user_id,
            'agent_email' => $agent?->email,
            'agent_domain_id' => $context->agent_domain_id === null ? null : (int) $context->agent_domain_id,
            'domain' => $domain?->domain ?? ($context->domain_snapshot['domain'] ?? null),
            'agent_domain' => $domain?->domain ?? ($context->domain_snapshot['domain'] ?? null),
            'plan_name' => $order?->plan?->name ?? ($context->pricing_snapshot['plan_name'] ?? null),
            'period' => $context->pricing_snapshot['period'] ?? $order?->period,
            'sale_amount' => (int) $context->sale_amount,
            'platform_cost' => (int) $context->cost_amount,
            'cost_amount' => (int) $context->cost_amount,
            'margin_amount' => (int) $resolved['margin_amount'],
            'payment_id' => $context->payment_id === null ? null : (int) $context->payment_id,
            'payment_name' => $payment?->name ?? ($context->payment_snapshot['name'] ?? null),
            'payment_code' => $payment?->payment ?? ($context->payment_snapshot['payment'] ?? null),
            'order_status' => $order?->status === null ? null : (int) $order->status,
            'context_status' => $context->status,
            'status' => $context->status,
            'hold_status' => $resolved['hold_status'],
            'capture_status' => $resolved['capture_status'],
            'abnormal_flags' => $resolved['abnormal_flags'],
            'created_at' => $context->created_at,
            'updated_at' => $context->updated_at,
        ];
    }

    private function activeDomainCount(int $agentUserId): int
    {
        return (int) AgentDomain::query()
            ->where('agent_user_id', $agentUserId)
            ->where('status', AgentDomain::STATUS_ACTIVE)
            ->count();
    }

    private function enabledPaymentCount(int $agentUserId): int
    {
        $collection = app(AgentCollectionService::class)->settings($agentUserId);
        if ($collection->mode === 'platform') {
            return Payment::where('owner_type', Payment::OWNER_PLATFORM)->where('payment', '!=', 'balance')
                ->whereIn('id', $collection->platform_enabled ? ($collection->payment_ids ?? []) : [])->where('enable', true)->count();
        }
        return (int) Payment::query()
            ->where('owner_type', Payment::OWNER_AGENT)
            ->where('owner_id', $agentUserId)
            ->where('enable', true)
            ->count();
    }

    private function validCostSiteId(?int $siteId): ?int
    {
        if ($siteId === null) {
            return null;
        }

        $site = Site::query()
            ->where('id', $siteId)
            ->where('status', Site::STATUS_ACTIVE)
            ->where('is_default', false)
            ->first();

        if ($site === null) {
            throw new ApiException('Cost site is not available');
        }

        return (int) $site->id;
    }

    /**
     * @return array{site_id: int|null, code: string|null, name: string, is_platform: bool}
     */
    private function costSitePayloadForAgent(int $agentUserId): array
    {
        $profile = AgentProfile::query()
            ->with('costSite')
            ->where('user_id', $agentUserId)
            ->first();

        if (!$profile || !$profile->cost_site_id || !$profile->costSite) {
            return $this->platformCostSitePayload();
        }

        return [
            'site_id' => (int) $profile->costSite->id,
            'code' => (string) $profile->costSite->code,
            'name' => (string) $profile->costSite->name,
            'is_platform' => false,
        ];
    }

    /**
     * @return array{site_id: null, code: null, name: string, is_platform: true}
     */
    private function platformCostSitePayload(): array
    {
        return [
            'site_id' => null,
            'code' => null,
            'name' => '主站',
            'is_platform' => true,
        ];
    }

    private function positiveInt(mixed $value, int $default): int
    {
        $value = (int) $value;

        return $value > 0 ? $value : $default;
    }
}
