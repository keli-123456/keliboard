<?php

namespace App\Jobs;

use App\Exceptions\ApiException;
use App\Services\TelegramService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendTelegramJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected $telegramId;
    protected $text;

    public $tries = 3;
    public $timeout = 10;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(int $telegramId, string $text)
    {
        $this->onQueue('send_telegram');
        $this->telegramId = $telegramId;
        $this->text = $text;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(TelegramService $telegramService): void
    {
        try {
            $telegramService->sendMessage($this->telegramId, $this->text, 'markdown');
        } catch (ApiException $e) {
            if (!$this->isUnrecoverableRecipientFailure($e)) {
                throw $e;
            }

            Log::warning('Telegram notification skipped because recipient is unavailable', [
                'chat_id' => $this->telegramId,
                'error' => $e->getMessage(),
            ]);
        }
    }

    private function isUnrecoverableRecipientFailure(ApiException $e): bool
    {
        $message = strtolower($e->getMessage());

        return str_contains($message, 'chat not found')
            || str_contains($message, 'bot was blocked by the user')
            || str_contains($message, 'user is deactivated');
    }
}
