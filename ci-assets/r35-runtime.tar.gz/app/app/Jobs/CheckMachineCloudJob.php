<?php
namespace App\Jobs;

use App\Services\ServerMachine\Cloud\MachineCloudService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUniqueUntilProcessing;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;

class CheckMachineCloudJob implements ShouldQueue, ShouldBeUniqueUntilProcessing
{
    use Dispatchable, InteractsWithQueue, Queueable;
    public int $tries = 1;
    public int $timeout = 60;
    public int $uniqueFor = 90;
    public function __construct(public readonly int $resourceId, public readonly int $revision) { $this->onConnection('redis'); $this->onQueue('admin_operations'); }
    public function uniqueId(): string { return $this->resourceId . ':' . $this->revision; }
    public function handle(MachineCloudService $service): void { $service->check($this->resourceId, $this->revision); }
}
